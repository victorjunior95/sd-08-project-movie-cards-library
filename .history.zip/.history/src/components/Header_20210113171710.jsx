// implement Header component here
import React from 'react';

class Header extends React.Component {
  render() {
    return (<div>
                <header>
                    <h1>Movie Cards Library</h1>
                </header>
            </div>);
  }
}

export default Header;
