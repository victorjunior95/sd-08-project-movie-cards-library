// implement MovieCard component here
import React from 'react';

class MovieCard extends React.Component {
render() {
    return (<div>
      <h1>testes</h1>
    </div>)
    }
}
export default MovieCard;