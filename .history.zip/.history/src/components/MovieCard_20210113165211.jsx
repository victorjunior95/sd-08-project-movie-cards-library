// implement MovieCard component here
import React from 'react';

class MovieCard extends React.Component {
render() {
    return (<h1>testes</h1>)
}
}
export default MovieCard;