import PropTypes from 'prop-types';
import React from 'react'
import MovieCard from './MovieCard';

class MovieList extends React.Component {
  render() {
    const { movies } = this.props;
    return (
      <section className="movie-list">
        {movies.map((movies) => (
          <MovieCard movies={ movies } key={ movies.title } />
        ))}
      </section>
    )
  }
}

MovieList.propTypes ={ movies: PropTypes.object.isRequired }
export default MovieList;