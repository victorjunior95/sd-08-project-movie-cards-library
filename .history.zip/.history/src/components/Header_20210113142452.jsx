// implement Header component here
import React from 'react';

class Header extends React.Component {
    render() {
    }
}

export default Header;