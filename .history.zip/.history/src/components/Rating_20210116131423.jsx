// implement Rating component here
import React from 'react';

class Rating extends React.Component {
  render() {
    const { Rating } = this.props;
    return (
      <div>
        <h5>Rating</h5>
      </div>);
  }
}

export default Rating;
