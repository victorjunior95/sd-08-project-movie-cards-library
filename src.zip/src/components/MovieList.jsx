// implement MovieList component here
import React from 'react';

class MovieList extends React.Component {
//   constructor(movies) {
//     super(movies);
//   }

  render() {
    return (
      <MovieList>
        {/* <MovieCard /> */}
      </MovieList>
    );
  }
}

export default MovieList;
