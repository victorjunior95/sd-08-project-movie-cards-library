// implement MovieCard component here
